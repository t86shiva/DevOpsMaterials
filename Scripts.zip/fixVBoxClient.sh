killall VBoxClient 2>&1 >/dev/null 
VBoxClient --clipboard
VBoxClient --draganddrop
VBoxClient --display
